Buenas noches Miguel. Aquí te dejo mi relación de ejercicios, no he llegado a completarlos.... me han faltado algunos de uso de expresiones que apenas encontraba nada por la web ni moodle ni nada. De todas maneras me gustaría poder terminarlas en clase al menos, para saber como se hacen.

Nota: Esto tiene tela de horas de curro detrás, aun así no he buscado respuestas en chatgpt, porque prefiero "aprender" intentando buscarme la vida yo.
Saludos.
